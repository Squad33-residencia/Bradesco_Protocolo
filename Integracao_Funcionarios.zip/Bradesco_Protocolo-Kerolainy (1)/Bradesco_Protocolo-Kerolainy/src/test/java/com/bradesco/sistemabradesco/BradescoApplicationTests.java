package com.bradesco.sistemabradesco;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BradescoApplicationTests {

	@Test
	void contextLoads() {
	}

}
