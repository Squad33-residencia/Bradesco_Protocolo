// package com.bradesco.sistemabradesco.services.implememtacao_interface;

// import com.bradesco.sistemabradesco.models.Protocolo;
// // import jakarta.persistence.EntityManager;
// // import jakarta.persistence.Persistence;

// import java.util.List;

// public class App {
//     // private static EntityManager entityManager;

//     /**
//      * @param args
//      */
//     public static void main(String[] args) {
//         // Cria uma nova instância de Analista
//         Analista analista = new Analista("i093485", "Pedro Campos", "pedro.campos@soubradesco.com.br", "ativo" );

//         // Obtem o EntityManager
//         // if (entityManager == null) {
//         //     entityManager = Persistence.createEntityManagerFactory("nomeDoPersistenceUnit").createEntityManager();
//         // }

//         // // Configura o EntityManager para Analista
//         // analista.setEntityManager(entityManager); // Esta linha está comentada e não faz nada

//         // Chama o método consultarProtocolo para obter uma lista de Protocolo
//         List<Protocolo> protocolos = analista.consultarProtocolo();

//         // Lógica par processar a Lista de Protocolos
//         for (Protocolo protocolo : protocolos) {
//             System.out.println("Protocolo ID: " + protocolo.getCodigo());
//             System.out.println("Protocolo Tipo:" + protocolo.getTipoProtocolo());
//         }
//     }
// }
