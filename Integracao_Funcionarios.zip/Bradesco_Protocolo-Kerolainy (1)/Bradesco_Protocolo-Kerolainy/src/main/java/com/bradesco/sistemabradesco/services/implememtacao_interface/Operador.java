package com.bradesco.sistemabradesco.services.implememtacao_interface;

import java.util.List;

import com.bradesco.sistemabradesco.models.Cargo;
import com.bradesco.sistemabradesco.models.Departamento;
import com.bradesco.sistemabradesco.models.Protocolo;

public class Operador implements Funcionario {
      	// atributos da classe
	private String codigo;
	private String nome;
	private String email;
	private String statusFuncionario;
	private Cargo cargo;
	private Departamento departamento;
    
    /* construtor */
    public Operador(){

    }

    /* metodos da interface */
    @Override
    public List<Protocolo> consultarProtocolo(){
        return null;

    }

    @Override
    public void tratarProtocolo(){

    }

    /* metodos específicos */
    // abrir protocolo

    /* getters and setters */
    public String getCodigo() {
        return codigo;
      }
    
      public void setCodigo(String codigo) {
        this.codigo = codigo;
      }
    
      public String getNome() {
        return nome;
      }
    
      public void setNome(String nome) {
        this.nome = nome;
      }
    
      public String getEmail() {
        return email;
      }
    
      public void setEmail(String email) {
        this.email = email;
      }
    
      public String getStatusFuncionario() {
        return statusFuncionario;
      }
    
      public void setStatusFuncionario(String statusFuncionario) {
        this.statusFuncionario = statusFuncionario;
      }
    
      public Cargo getCargo() {
        return cargo;
      }
    
      public void setCargo(Cargo cargo) {
        this.cargo = cargo;
      }
    
      public Departamento getDepartamento() {
        return departamento;
      }
    
      public void setDepartamento(Departamento departamento) {
        this.departamento = departamento;
      }



}
