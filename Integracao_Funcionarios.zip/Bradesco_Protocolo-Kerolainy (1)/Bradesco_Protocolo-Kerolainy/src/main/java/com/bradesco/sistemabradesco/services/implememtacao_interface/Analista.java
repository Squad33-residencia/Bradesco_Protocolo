package com.bradesco.sistemabradesco.services.implememtacao_interface;

import java.util.List;

import javax.swing.text.html.parser.Entity;

import com.bradesco.sistemabradesco.models.Cargo;
import com.bradesco.sistemabradesco.models.Departamento;
import com.bradesco.sistemabradesco.models.Protocolo;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;

public class Analista implements Funcionario {
    // Atributos da classe
    private String codigo;
    private String nome;
    private String email;
    private String statusFuncionario;
    private Cargo cargo;
    private Departamento departamento;
    private Protocolo protocolo;

    // Injeção de Dependência para EntityManager
    @PersistenceContext
    private EntityManager entityManager;

    // Construtor vazio
    public Analista() {
        
    }

        // Construtor com parâmetros
        public Analista(String codigo, String nome, String email, String statusFuncionario, Cargo cargo, Departamento departamento) {
            this.codigo = codigo;
            this.nome = nome;
            this.email = email;
            this.statusFuncionario = statusFuncionario;
            this.cargo = cargo;
            this.departamento = departamento;
        }
    

    // Métodos da interface
    @Override
    public List<Protocolo> consultarProtocolo() {
  

        // Construir consulta JPQL
        TypedQuery<Protocolo> query = entityManager.createQuery("SELECT p FROM Protocolo p", Protocolo.class);
     

        // Executar consulta e retornar lista de protocolos
        List<Protocolo> protocolos = query.getResultList();

       

        return protocolos;
    }

    

    @Override
    public void tratarProtocolo() {
        // código de tratamento do protocolo
    }

    /* metódos específicos */

    // void filtrarProtocolosPorTipo(String tipo);
    // void filtrarProtocolosPorDataPrazo(LocalDate dataPrazo);
    // void filtrarProtocolosPorStatus(String status);
    // void agilizarProtocolo(Long idProtocolo);

    /* getters and setters */
    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getStatusFuncionario() {
        return statusFuncionario;
    }

    public void setStatusFuncionario(String statusFuncionario) {
        this.statusFuncionario = statusFuncionario;
    }

    public Cargo getCargo() {
        return cargo;
    }

    public void setCargo(Cargo cargo) {
        this.cargo = cargo;
    }

    public Departamento getDepartamento() {
        return departamento;
    }

    public void setDepartamento(Departamento departamento) {
        this.departamento = departamento;
    }

    public void setEntityManager(EntityManager entityManager2) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'setEntityManager'");
    }
    
}



