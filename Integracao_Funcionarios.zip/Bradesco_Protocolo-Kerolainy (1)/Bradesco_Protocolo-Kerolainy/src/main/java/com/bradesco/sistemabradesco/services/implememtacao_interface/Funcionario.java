package com.bradesco.sistemabradesco.services.implememtacao_interface;

import java.util.List;

import com.bradesco.sistemabradesco.models.Protocolo;

public interface Funcionario {
    public List<Protocolo> consultarProtocolo();
    public void tratarProtocolo();
}
