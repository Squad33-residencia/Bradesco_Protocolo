# Bradesco_Protocolo
Sistema de gerenciamento e atendimento de protocolos para a Residência Takeoff 2024.1 juntamente com a empresa Bradesco.
